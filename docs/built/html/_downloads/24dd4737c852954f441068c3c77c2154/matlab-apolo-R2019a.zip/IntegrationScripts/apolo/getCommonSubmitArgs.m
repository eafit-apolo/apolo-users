function commonSubmitArgs = getCommonSubmitArgs(cluster, numWorkers)
% Get any additional submit arguments for the Slurm sbatch command
% that are common to both independent and communicating jobs.

% Copyright 2016-2019 The MathWorks, Inc.

% General wiki: https://apolo-docs.readthedocs.io/en/latest/index.html

% MATLAB Specific Wiki: https://apolo-docs.readthedocs.io/en/latest/software/programminglanguages/matlab

commonSubmitArgs = '';

% Number of cores/node
ppn = validatedPropValue(cluster, 'ProcsPerNode', 'double');
if ppn>0
    % Don't request more cores/node than workers
    ppn = min(numWorkers,ppn);
    commonSubmitArgs = sprintf('%s --ntasks-per-node=%d',commonSubmitArgs,ppn);
end
commonSubmitArgs = sprintf('%s --ntasks-per-core=1',commonSubmitArgs);

%% REQUIRED %%

% TimeLimit
wt = validatedPropValue(cluster, 'TimeLimit', 'char');
if isempty(wt)
    emsg = sprintf(['\n\t>> %% Must set TimeLimit.  E.g.\n\n', ...
                    '\t>> c = parcluster;\n', ...
                    '\t>> %% Set TimeLimit to 5 hours\n', ...
                    '\t>> c.AdditionalProperties.TimeLimit = ''05:00:00'';\n', ...
                    '\t>> c.saveProfile\n\n']);
    error(emsg) %#ok<SPERR>
else
    commonSubmitArgs = [commonSubmitArgs ' -t ' wt];
end

%% OPTIONAL %%

% AccountName
an = validatedPropValue(cluster, 'AccountName', 'char');
if ~isempty(an)
    commonSubmitArgs = [commonSubmitArgs ' -A ' an];
end

% Constraint support (Disabled)
%con = validatedPropValue(cluster, 'Constraint', 'char');
%if ~isempty(con)
%    commonSubmitArgs = [commonSubmitArgs ' --constraint=' con];
%end

% Email notification
ea = validatedPropValue(cluster, 'EmailAddress', 'char');
if ~isempty(ea)
    mt = validatedPropValue(cluster, 'EmailType', 'char');
    if ~isempty(mt)
        commonSubmitArgs = [commonSubmitArgs ' --mail-type=' mt ' --mail-user=' ea];
    else
        commonSubmitArgs = [commonSubmitArgs ' --mail-type=ALL --mail-user=' ea];
    end
end

% Physical Memory used by a single core
mu = validatedPropValue(cluster, 'MemUsage', 'char');
if ~isempty(mu)
    commonSubmitArgs = [commonSubmitArgs ' --mem-per-cpu=' mu];
end

% Partition / GRES (GPU) 
ngpus = validatedPropValue(cluster, 'NumGpus', 'double'); 
pt = validatedPropValue(cluster, 'Partition', 'char');
if ngpus>0
    commonSubmitArgs = sprintf('%s -p accel --gres=gpu:%d', commonSubmitArgs,ngpus);
else
    if ~isempty(pt)
        commonSubmitArgs = [commonSubmitArgs ' -p ' pt];
    end
end

% Reservation feature support (SLURM)
res = validatedPropValue(cluster, 'Reservation', 'char');
if ~isempty(res)
    commonSubmitArgs = [commonSubmitArgs ' --reservation=' res];
end

% Catch-all
asa = validatedPropValue(cluster, 'AdditionalSubmitArgs', 'char');
if ~isempty(asa)
    commonSubmitArgs = [commonSubmitArgs ' ' asa];
end

commonSubmitArgs = strtrim(commonSubmitArgs);
function commonSubmitArgs = getCommonSubmitArgs(cluster, numWorkers)
% Get any additional submit arguments for the Slurm sbatch command
% that are common to both independent and communicating jobs.

% Copyright 2016-2018 The MathWorks, Inc.

commonSubmitArgs = '';

%% MANDATORY

% TimeLimit
wt = validatedPropValue(cluster, 'TimeLimit', 'char');
if ~isempty(wt)
    commonSubmitArgs = [commonSubmitArgs ' -t ' wt];
end

%% OPTIONAL

%% Number of process (cores) per node
%ppn = validatedPropValue(cluster, 'ProcsPerNode', 'double');
%if ~isempty(ppn) && ppn>0
%    % Don't request more cores/node than workers
%    ppn = min(numWorkers,ppn);
%    commonSubmitArgs = sprintf('%s --ntasks-per-node=%d', commonSubmitArgs, ppn);
%end

% GRES (GPU) 
ngpus = validatedPropValue(cluster, 'NumGpus', 'double'); 
if ngpus>0
   commonSubmitArgs = [commonSubmitArgs ' --gres=gpu:' num2str(ngpus)];
end

% Partition
pt = validatedPropValue(cluster, 'Partition', 'char');
if ~isempty(pt)
    commonSubmitArgs = [commonSubmitArgs ' -p ' pt];
end

% Physical Memory used by the whole program per machine
mu = validatedPropValue(cluster, 'MemUsage', 'char');
if ~isempty(mu)
    % Default (in GB)
    commonSubmitArgs = [commonSubmitArgs ' --mem=' mu];
end

%% Architecture support (Disabled)
%a = validatedPropValue(cluster, 'Arch', 'char');
%if ~isempty(a)
%    commonSubmitArgs = [commonSubmitArgs ' --constraint=' a];
%end

% Reservation feature support (SLURM)
res = validatedPropValue(cluster, 'Reservation', 'char');
if ~isempty(res)
    commonSubmitArgs = [commonSubmitArgs ' --reservation=' res];
end

% AccountName
an = validatedPropValue(cluster, 'AccountName', 'char');
if ~isempty(an)
    commonSubmitArgs = [commonSubmitArgs ' -A ' an];
end

% Email notification
ea = validatedPropValue(cluster, 'EmailAddress', 'char');
if ~isempty(ea)
    mt = validatedPropValue(cluster, 'EmailType', 'char');
    if ~isempty(mt)
        commonSubmitArgs = [commonSubmitArgs ' --mail-type=' mt ' --mail-user=' ea];
    else
        commonSubmitArgs = [commonSubmitArgs ' --mail-type=ALL --mail-user=' ea];
    end
end

% Remote license support by SLURM
commonSubmitArgs = sprintf('%s --licenses=matlab@lm.apolo.eafit.edu.co:%d', commonSubmitArgs, numWorkers);

commonSubmitArgs = sprintf('%s', commonSubmitArgs);

% Anything else (catch-all)
asa = validatedPropValue(cluster, 'AdditionalSubmitArgs', 'char');
if ~isempty(asa)
    commonSubmitArgs = [commonSubmitArgs ' ' asa];
end

commonSubmitArgs = strtrim(commonSubmitArgs);
